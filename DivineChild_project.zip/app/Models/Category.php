<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    protected $table = "category";

    protected $fillable = [
        "title",
    ];

    public function documents()
    {
        return $this->hasMany(Documents::class);
    }
}
