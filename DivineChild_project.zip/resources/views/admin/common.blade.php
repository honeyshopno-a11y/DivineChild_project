<!DOCTYPE html>
<html lang="en" class="light-style layout-menu-fixed" dir="ltr" data-theme="theme-default" data-assets-path="../assets/"
    data-template="vertical-menu-template-free">

<head>
    <meta charset="utf-8" />
    <meta name="viewport"
        content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />
    <title>@yield('title', 'Dashboard')</title>
    <meta name="description" content="" />
    <!-- Favicon -->
    <!-- <link rel="icon" type="image/x-icon" href="{{ asset('assets/img/icon/logo.png') }}" /> -->
    <link rel="icon" type="image/x-icon" href="{{ asset('assets/img/icon/logo.png') }}" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
        href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" />
    {{-- <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="{{ env('APP-URL').'admin-css/assets/vendor/fonts/boxicons.css' }}" />
    <!-- Core CSS -->
    <link rel="stylesheet" href="{{ env('APP-URL').'admin-css/assets/vendor/css/core.css' }}" />
    <link rel="stylesheet" href="{{ env('APP-URL').'admin-css/assets/vendor/css/theme-default.css' }}" />
    <link rel="stylesheet" href="{{ env('APP-URL').'admin-css/assets/css/demo.css' }}" />
    <!-- Vendors CSS -->
    <link rel="stylesheet"
        href="{{ env('APP-URL').'admin-css/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css' }}" />
    <link rel="stylesheet" href="{{ env('APP-URL').'admin-css/assets/vendor/libs/apex-charts/apex-charts.css' }}" />
    <!-- Page CSS -->
    <!-- Helpers -->
    <script src="{{ env('APP-URL').'admin-css/assets/vendor/js/helpers.js' }}"></script>
    <script src="{{ env('APP-URL').'admin-css/assets/js/config.js' }}"></script> --}}

    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="{{ asset('admin_css/assets/vendor/fonts/boxicons.css') }}" />
    <!-- Core CSS -->
    <link rel="stylesheet" href="{{ asset('admin_css/assets/vendor/css/core.css') }}" />
    <link rel="stylesheet" href="{{ asset('admin_css/assets/vendor/css/theme-default.css') }}" />
    <link rel="stylesheet" href="{{ asset('admin_css/assets/css/demo.css') }}" />
    <!-- Vendors CSS -->
    <link rel="stylesheet" href="{{ asset('admin_css/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css') }}" />
    <link rel="stylesheet" href="{{ asset('admin_css/assets/vendor/libs/apex-charts/apex-charts.css') }}" />
    <!-- Page CSS -->
    <!-- Helpers -->
    <script src="{{ asset('admin_css/assets/vendor/js/helpers.js') }}"></script>
    <script src="{{ asset('admin_css/assets/js/config.js') }}"></script>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <link rel="stylesheet" href="//cdn.datatables.net/2.3.1/css/dataTables.dataTables.min.css">
    <script src="//cdn.datatables.net/2.3.1/js/dataTables.min.js"></script>
    <link href='https://cdn.boxicons.com/fonts/basic/boxicons.min.css' rel='stylesheet'>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .menu-link i {
            margin-right: 10px;
        }
    </style>
</head>

<body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">
            <!-- Menu -->

            <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
                <div class="app-brand demo">
                    <a href="#" class="app-brand-link">
                        {{-- <span class="app-brand-logo demo">
                            <svg width="25" viewBox="0 0 25 42" version="1.1" xmlns="http://www.w3.org/2000/svg"
                                xmlns:xlink="http://www.w3.org/1999/xlink">
                                <defs>
                                    <path
                                        d="M13.7918663,0.358365126 L3.39788168,7.44174259 C0.566865006,9.69408886 -0.379795268,12.4788597 0.557900856,15.7960551 C0.68998853,16.2305145 1.09562888,17.7872135 3.12357076,19.2293357 C3.8146334,19.7207684 5.32369333,20.3834223 7.65075054,21.2172976 L7.59773219,21.2525164 L2.63468769,24.5493413 C0.445452254,26.3002124 0.0884951797,28.5083815 1.56381646,31.1738486 C2.83770406,32.8170431 5.20850219,33.2640127 7.09180128,32.5391577 C8.347334,32.0559211 11.4559176,30.0011079 16.4175519,26.3747182 C18.0338572,24.4997857 18.6973423,22.4544883 18.4080071,20.2388261 C17.963753,17.5346866 16.1776345,15.5799961 13.0496516,14.3747546 L10.9194936,13.4715819 L18.6192054,7.984237 L13.7918663,0.358365126 Z"
                                        id="path-1"></path>
                                    <path
                                        d="M5.47320593,6.00457225 C4.05321814,8.216144 4.36334763,10.0722806 6.40359441,11.5729822 C8.61520715,12.571656 10.0999176,13.2171421 10.8577257,13.5094407 L15.5088241,14.433041 L18.6192054,7.984237 C15.5364148,3.11535317 13.9273018,0.573395879 13.7918663,0.358365126 C13.5790555,0.511491653 10.8061687,2.3935607 5.47320593,6.00457225 Z"
                                        id="path-3"></path>
                                    <path
                                        d="M7.50063644,21.2294429 L12.3234468,23.3159332 C14.1688022,24.7579751 14.397098,26.4880487 13.008334,28.506154 C11.6195701,30.5242593 10.3099883,31.790241 9.07958868,32.3040991 C5.78142938,33.4346997 4.13234973,34 4.13234973,34 C4.13234973,34 2.75489982,33.0538207 2.37032616e-14,31.1614621 C-0.55822714,27.8186216 -0.55822714,26.0572515 -4.05231404e-15,25.8773518 C0.83734071,25.6075023 2.77988457,22.8248993 3.3049379,22.52991 C3.65497346,22.3332504 5.05353963,21.8997614 7.50063644,21.2294429 Z"
                                        id="path-4"></path>
                                    <path
                                        d="M20.6,7.13333333 L25.6,13.8 C26.2627417,14.6836556 26.0836556,15.9372583 25.2,16.6 C24.8538077,16.8596443 24.4327404,17 24,17 L14,17 C12.8954305,17 12,16.1045695 12,15 C12,14.5672596 12.1403557,14.1461923 12.4,13.8 L17.4,7.13333333 C18.0627417,6.24967773 19.3163444,6.07059163 20.2,6.73333333 C20.3516113,6.84704183 20.4862915,6.981722 20.6,7.13333333 Z"
                                        id="path-5"></path>
                                </defs>
                                <g id="g-app-brand" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                    <g id="Brand-Logo" transform="translate(-27.000000, -15.000000)">
                                        <g id="Icon" transform="translate(27.000000, 15.000000)">
                                            <g id="Mask" transform="translate(0.000000, 8.000000)">
                                                <mask id="mask-2" fill="white">
                                                    <use xlink:href="#path-1"></use>
                                                </mask>
                                                <use fill="#696cff" xlink:href="#path-1"></use>
                                                <g id="Path-3" mask="url(#mask-2)">
                                                    <use fill="#696cff" xlink:href="#path-3"></use>
                                                    <use fill-opacity="0.2" fill="#FFFFFF" xlink:href="#path-3"></use>
                                                </g>
                                                <g id="Path-4" mask="url(#mask-2)">
                                                    <use fill="#696cff" xlink:href="#path-4"></use>
                                                    <use fill-opacity="0.2" fill="#FFFFFF" xlink:href="#path-4"></use>
                                                </g>
                                            </g>
                                            <g id="Triangle"
                                                transform="translate(19.000000, 11.000000) rotate(-300.000000) translate(-19.000000, -11.000000) ">
                                                <use fill="#696cff" xlink:href="#path-5"></use>
                                                <use fill-opacity="0.2" fill="#FFFFFF" xlink:href="#path-5"></use>
                                            </g>
                                        </g>
                                    </g>
                                </g>
                            </svg>
                        </span> --}}
                        <a href="{{ route('dashboard') }}" class="pb-3 px-0 text-start">
                            <!-- <img src="{{ asset('assets/img/logo/logo-1.webp') }}" alt="logo" class="img-fluid p-3"> -->
                            <img src="{{ asset('assets/img/icon/main-logo.png') }}" alt="logo" class="img-fluid p-3">

                        </a>
                    </a>

                    <a href="#" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
                        <i class="bx bx-chevron-left bx-sm align-middle"></i>
                    </a>
                </div>

                <div class="menu-inner-shadow"></div>

                <ul class="menu-inner py-1">
                    <!-- Dashboard -->

                    <li class="menu-item {{ request()->is('dashboard*') ? 'active' : '' }}">
                        <a href="{{ route('dashboard') }}" class="menu-link">
                            <i class="bx bx-home-smile"></i>
                            <div data-i18n="Analytics">Dashboard</div>
                        </a>
                    </li>

                    <li class="menu-item {{ request()->is('slider*') ? 'active' : '' }}">
                        <a href="{{ route('slider-list') }}" class="menu-link">
                            <i class="bx bx-slideshow"></i>
                            <div data-i18n="Analytics">Home-Slider</div>
                        </a>
                    </li>

                    <li class="menu-item {{ request()->is('news*') ? 'active' : '' }}">
                        <a href="{{ route('news-list') }}" class="menu-link">
                            <i class="bx bx-news"></i>
                            <div data-i18n="Analytics">News</div>
                        </a>
                    </li>


                    <li class="menu-item
                        {{
    request()->routeIs('public-disclosure-title-*')
    || (request()->routeIs('public-disclosure-*')
        && !request()->routeIs('public-disclosure-title-*'))
    ? 'active open' : ''
                        }}">

                        <a href="javascript:void(0);" class="menu-link menu-toggle">
                            <i class="bx bx-file"></i>
                            <div>Public Disclosure</div>
                        </a>

                        <ul class="menu-sub">

                            <!-- Public Disclosure Title -->
                            <li class="menu-item {{ request()->routeIs('public-disclosure-title-*') ? 'active' : '' }}">
                                <a href="{{ route('public-disclosure-title-list') }}" class="menu-link">
                                    <div>Public Disclosure Title</div>
                                </a>
                            </li>

                            <!-- Public Disclosure -->
                            <li class="menu-item {{ request()->routeIs('public-disclosure-*')
    && !request()->routeIs('public-disclosure-title-*') ? 'active' : '' }}">
                                <a href="{{ route('public-disclosure-list') }}" class="menu-link">
                                    <div>Public Disclosure</div>
                                </a>
                            </li>

                        </ul>

                    </li>





                    <li class="menu-item {{ request()->is('gallery*') ? 'active' : '' }}">
                        <a href="{{ route('gallery-list') }}" class="menu-link">
                            <i class="bx bx-image-alt"></i>
                            <div data-i18n="Analytics">Gallery</div>
                        </a>
                    </li>

                    <li class="menu-item {{ request()->is('syllabus*') ? 'active' : '' }}">
                        <a href="{{ route('syllabus-list') }}" class="menu-link">
                            <i class="bx bx-book-open"></i>
                            <div data-i18n="Analytics">Syllabus</div>
                        </a>
                    </li>

                    <li class="menu-item {{ request()->is('ExamSchedule*') ? 'active' : '' }}">
                        <a href="{{ route('ExamSchedule-list') }}" class="menu-link">
                            <i class="bx bx-calendar-event"></i>
                            <div data-i18n="Analytics">Exam Schedule</div>
                        </a>
                    </li>

                    <li class="menu-item {{
    request()->routeIs('primary.to.secondary.exam.schedule.*')
    || request()->routeIs('pre.board.dates.*')
    || request()->routeIs('practical.examination.schedule.*')
    ? 'active open' : ''
}}">
                        <a href="javascript:void(0);" class="menu-link menu-toggle">
                            <i class="bx bx-time-five"></i>
                            <div>Time Table</div>
                        </a>

                        <ul class="menu-sub">

                            <li class="menu-item {{
    request()->routeIs('primary.to.secondary.exam.schedule.*')
    ? 'active' : ''
        }}">
                                <a href="{{ route('primary.to.secondary.exam.schedule.list') }}" class="menu-link">
                                    <div>Primary to Secondary Exam Schedule</div>
                                </a>
                            </li>

                            <li class="menu-item {{
    request()->routeIs('pre.board.dates.*')
    ? 'active' : ''
        }}">
                                <a href="{{ route('pre.board.dates.list') }}" class="menu-link">
                                    <div>Pre-Board Dates</div>
                                </a>
                            </li>

                            <li class="menu-item {{
    request()->routeIs('practical.examination.schedule.*')
    ? 'active' : ''
        }}">
                                <a href="{{ route('practical.examination.schedule.list') }}" class="menu-link">
                                    <div>Practical Examination Schedule</div>
                                </a>
                            </li>

                        </ul>
                    </li>

                    <li class="menu-item {{ request()->is('holidayList*') ? 'active' : '' }}">
                        <a href="{{ route('holiday-list') }}" class="menu-link">
                            <i class="bx bx-calendar-star"></i>
                            <div data-i18n="Analytics">Holiday List</div>
                        </a>
                    </li>

                    <li class="menu-item {{ request()->is('ageCriteria*') ? 'active' : '' }}">
                        <a href="{{ route('ageCriteria-list') }}" class="menu-link">
                            <i class="bx bx-user-check"></i>
                            <div data-i18n="Analytics">Age Criteria</div>
                        </a>
                    </li>



                    <li class="menu-item
                        {{ request()->routeIs('category-*')
    || request()->routeIs('document-*')
    || request()->routeIs('doc-contact')
    ? 'active open' : '' }}">

                        <a href="javascript:void(0);" class="menu-link menu-toggle">
                            <i class="bx bx-folder-open"></i>
                            <div>Required Documents</div>
                        </a>

                        <ul class="menu-sub">

                            <!-- Category -->
                            <li class="menu-item {{ request()->routeIs('category-*') ? 'active' : '' }}">
                                <a href="{{ route('category-list') }}" class="menu-link">
                                    <div>Category</div>
                                </a>
                            </li>

                            <!-- Documents -->
                            <li class="menu-item {{ request()->routeIs('document-*') ? 'active' : '' }}">
                                <a href="{{ route('document-list') }}" class="menu-link">
                                    <div>Documents</div>
                                </a>
                            </li>

                            <!-- Contact -->
                            <li class="menu-item {{ request()->routeIs('doc-contact') ? 'active' : '' }}">
                                <a href="{{ route('doc-contact') }}" class="menu-link">
                                    <div>Contact</div>
                                </a>
                            </li>

                        </ul>

                    </li>

                    <li class="menu-item {{ request()->is('contact*') ? 'active' : '' }}">
                        <a href="{{ route('contact') }}" class="menu-link">
                            <i class="bx bx-phone"></i>
                            <div data-i18n="Analytics">Contact</div>
                        </a>
                    </li>

                    <li class="menu-item {{ request()->is('award*') ? 'active' : '' }}">
                        <a href="{{ route('award-list') }}" class="menu-link">
                            <i class="bx bx-trophy"></i>
                            <div data-i18n="Analytics">Awards</div>
                        </a>
                    </li>

                    <li class="menu-item {{ request()->is('event*') ? 'active' : '' }}">
                        <a href="{{ route('event-list') }}" class="menu-link">
                            <i class="bx bx-calendar"></i>
                            <div data-i18n="Analytics">Events</div>
                        </a>
                    </li>

                    <li class="menu-item {{ request()->is('management*') ? 'active' : '' }}">
                        <a href="{{ route('management-list') }}" class="menu-link">
                            <i class="bx bx-group"></i>
                            <div data-i18n="Analytics">Management</div>
                        </a>
                    </li>


                    <li class="menu-item {{
    request()->routeIs('fees-structure-list')
    || request()->routeIs('fees-structure-add')
    || request()->routeIs('fees-structure-edit')
    || request()->routeIs('fees-structure-details-list')
    || request()->routeIs('fees-structure-details-add')
    || request()->routeIs('fees-structure-details-edit')
    || request()->routeIs('school-time-list')
    || request()->routeIs('school-time-add')
    || request()->routeIs('school-time-edit')
    || request()->routeIs('school-activity-list')
    || request()->routeIs('school-activity-add')
    || request()->routeIs('school-activity-edit')
    ? 'active open' : ''
}}">

                        <a href="javascript:void(0);" class="menu-link menu-toggle">
                            <i class="bx bx-rupee menu-icon tf-icons"></i>
                            <div>Fees Structure</div>
                        </a>

                        <ul class="menu-sub">

                            <!-- Fees Structure -->
                            <li class="menu-item {{
    request()->routeIs('fees-structure-list')
    || request()->routeIs('fees-structure-add')
    || request()->routeIs('fees-structure-edit')
    ? 'active' : ''
        }}">
                                <a href="{{ route('fees-structure-list') }}" class="menu-link">
                                    <div>Fees Structure List</div>
                                </a>
                            </li>

                            <!-- Fees Structure Details -->
                            <li class="menu-item {{
    request()->routeIs('fees-structure-details-list')
    || request()->routeIs('fees-structure-details-add')
    || request()->routeIs('fees-structure-details-edit')
    ? 'active' : ''
        }}">
                                <a href="{{ route('fees-structure-details-list') }}" class="menu-link">
                                    <div>Fees Structure List Details</div>
                                </a>
                            </li>

                            <!-- School Timing -->
                            <li class="menu-item {{
    request()->routeIs('school-time-list')
    || request()->routeIs('school-time-add')
    || request()->routeIs('school-time-edit')
    ? 'active' : ''
        }}">
                                <a href="{{ route('school-time-list') }}" class="menu-link">
                                    <div>School Timing</div>
                                </a>
                            </li>

                            <!-- School Activities -->
                            <li class="menu-item {{
    request()->routeIs('school-activity-list')
    || request()->routeIs('school-activity-add')
    || request()->routeIs('school-activity-edit')
    ? 'active' : ''
        }}">
                                <a href="{{ route('school-activity-list') }}" class="menu-link">
                                    <div>School Activities</div>
                                </a>
                            </li>

                        </ul>

                    </li>


                    <li class="menu-item {{ request()->is('staff*') ? 'active' : '' }}">
                        <a href="{{ url('staff-list') }}" class="menu-link">
                            <i class="bx bx-user-circle"></i>
                            <div data-i18n="Analytics">Staff</div>
                        </a>
                    </li>
                    <li class="menu-item {{ request()->is('inquiry-form*') ? 'active' : '' }}">
                        <a href="{{ route('inquiry-form-list') }}" class="menu-link">
                            <i class="bx bx-message-dots"></i>
                            <div data-i18n="Analytics">Inquiry</div>
                        </a>
                    </li>

                    <li class="menu-item {{ request()->is('facilities.') ? 'active' : '' }}">
                        <a href="{{ route('facilities.index') }}" class="menu-link">
                            <i class='bxr  bx-clipboard-detail menu-icon tf-icons'></i>
                            <div data-i18n="Analytics">Facilities</div>
                        </a>
                    </li>
                    <!-- Layouts -->
                </ul>

            </aside>
            <!-- / Menu -->

            <!-- Layout container -->
            <div class="layout-page">
                <!-- Navbar -->

                <nav class="layout-navbar  navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme"
                    id="layout-navbar">
                    <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
                        <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
                            <i class="bx bx-menu bx-sm"></i>
                        </a>
                    </div>

                    <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
                        <!-- Search -->
                        <div class="navbar-nav align-items-center">
                            <div class="nav-item d-flex align-items-center">
                                {{-- <i class="bx bx-search fs-4 lh-0"></i>
                                <input type="text" class="form-control border-0 shadow-none" placeholder="Search..."
                                    aria-label="Search..." /> --}}
                            </div>
                        </div>
                        <!-- /Search -->

                        <ul class="navbar-nav flex-row align-items-center ms-auto">
                            <!-- Place this tag where you want the button to render. -->
                            {{-- <li class="nav-item lh-1 me-3">
                                <a class="github-button"
                                    href="https://github.com/themeselection/sneat-html-admin-template-free"
                                    data-icon="octicon-star" data-size="large" data-show-count="true"
                                    aria-label="Star themeselection/sneat-html-admin-template-free on GitHub">Star</a>
                            </li> --}}

                            <!-- User -->
                            <li class="nav-item navbar-dropdown dropdown-user dropdown">
                                <a class="nav-link dropdown-toggle hide-arrow" href="#" data-bs-toggle="dropdown">
                                    <div class="avatar avatar-online">
                                        <img src="{{ asset('admin_css/assets/img/avatars/1.png') }}" alt
                                            class="w-px-40 h-auto rounded-circle" />
                                    </div>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li>
                                        <a class="dropdown-item" href="#">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 me-3">
                                                    <div class="avatar avatar-online">
                                                        <img src="{{ asset('admin_css/assets/img/avatars/1.png') }}" alt
                                                            class="w-px-40 h-auto rounded-circle" />
                                                    </div>
                                                </div>
                                                <div class="flex-grow-1">
                                                    <span class="fw-semibold d-block">{{ Auth::user()->name }}</span>
                                                    {{-- <small class="text-muted">Admin</small> --}}
                                                </div>

                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <div class="dropdown-divider"></div>
                                    </li>

                                    <li>
                                        <a class="dropdown-item" href="{{ route('logout') }}" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            <i class="bx bx-power-off me-2"></i>
                                            <span class="align-middle">Log Out</span>
                                            <form id="logout-form" action="{{ route('logout') }}" method="POST"
                                                class="d-none">
                                                @csrf
                                            </form>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <!--/ User -->
                        </ul>
                    </div>
                </nav>

                <!-- / Navbar -->

                <!-- Content wrapper -->
                <div class="content-wrapper">
                    <!-- Content -->
                    @yield('content')
                    {{-- <div class="container-xxl flex-grow-1 container-p-y">
                    </div> --}}
                    <!-- / Content -->

                    <!-- Footer -->
                    {{-- <footer class="content-footer footer bg-footer-theme">
                        <div
                            class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
                            <div class="mb-2 mb-md-0">
                                ©
                                <script>
                                    document.write(new Date().getFullYear());
                                </script>
                                , made with ❤️ by
                                <a href="https://themeselection.com" target="-blank"
                                    class="footer-link fw-bolder">ThemeSelection</a>
                            </div>
                            <div>
                                <a href="https://themeselection.com/license/" class="footer-link me-4"
                                    target="-blank">License</a>
                                <a href="https://themeselection.com/" target="-blank" class="footer-link me-4">More
                                    Themes</a>

                                <a href="https://themeselection.com/demo/sneat-bootstrap-html-admin-template/documentation/"
                                    target="-blank" class="footer-link me-4">Documentation</a>

                                <a href="https://github.com/themeselection/sneat-html-admin-template-free/issues"
                                    target="-blank" class="footer-link me-4">Support</a>
                            </div>
                        </div>
                    </footer> --}}
                    <!-- / Footer -->

                    <div class="content-backdrop fade"></div>
                </div>
                <!-- Content wrapper -->
            </div>
            <!-- / Layout page -->
        </div>

        <!-- Overlay -->
        <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    <!-- / Layout wrapper -->
    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script>
        $(document).ready(function () {
            $('#myTable').DataTable();
        });

        function confirmDelete(event, url) {
            event.preventDefault();

            Swal.fire({
                title: "Are you sure?",
                text: "You won't be able to revert this!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#d33",
                cancelButtonColor: "#3085d6",
                confirmButtonText: "Yes, delete it!"
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = url; // ✅ Redirect only if confirmed
                }
            });
        }

        setTimeout(() => {
            document.getElementById('custom-alert').style.display = "none";
        }, 5000);
    </script>

    {{--
    <script src="{{ asset('admin-css/assets/vendor/libs/jquery/jquery.js') }}"></script> --}}
    <script src="{{ asset('admin_css/assets/vendor/libs/popper/popper.js') }}"></script>
    <script src="{{ asset('admin_css/assets/vendor/js/bootstrap.js') }}"></script>
    <script src="{{ asset('admin_css/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js') }}"></script>
    <script src="{{ asset('admin_css/assets/vendor/js/menu.js') }}"></script>
    <!-- endbuild -->
    <!-- Vendors JS -->
    <script src="{{ asset('admin_css/assets/vendor/libs/apex-charts/apexcharts.js') }}"></script>
    <!-- Main JS -->
    <script src="{{ asset('admin_css/assets/js/main.js') }}"></script>
    <!-- Page JS -->
    <script src="{{ asset('admin_css/assets/js/dashboards-analytics.js') }}"></script>
    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
</body>

</html>